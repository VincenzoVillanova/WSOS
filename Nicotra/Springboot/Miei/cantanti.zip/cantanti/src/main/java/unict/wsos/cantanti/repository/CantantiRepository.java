package unict.wsos.cantanti.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import unict.wsos.cantanti.model.Cantanti;

public interface CantantiRepository extends JpaRepository<Cantanti, Long> {

}
